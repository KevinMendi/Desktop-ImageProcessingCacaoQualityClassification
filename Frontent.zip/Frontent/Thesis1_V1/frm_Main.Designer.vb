﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Main))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.pnl_AB = New System.Windows.Forms.Panel()
        Me.pnl_step3 = New System.Windows.Forms.Panel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.lbl_Ototal = New System.Windows.Forms.Label()
        Me.BunifuFlatButton2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.lbl_pm = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.gauge_Reject = New Bunifu.Framework.UI.BunifuGauge()
        Me.gauge_Over = New Bunifu.Framework.UI.BunifuGauge()
        Me.gauge_Well = New Bunifu.Framework.UI.BunifuGauge()
        Me.gauge_Under = New Bunifu.Framework.UI.BunifuGauge()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.pnl_step1 = New System.Windows.Forms.Panel()
        Me.btn_capture = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.btn_new = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.btn_cancel = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.btn_save = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.btn_start = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.pnl_step2 = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.BunifuProgressBar1 = New Bunifu.Framework.UI.BunifuProgressBar()
        Me.BunifuThinButton21 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.pb2 = New System.Windows.Forms.PictureBox()
        Me.pb1 = New System.Windows.Forms.PictureBox()
        Me.pb0 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.btn_step1 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.btn_step3 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.btn_step2 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.pnl_UP = New System.Windows.Forms.Panel()
        Me.lbl_ID = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label148 = New System.Windows.Forms.Label()
        Me.BunifuThinButton26 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton25 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton24 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton23 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.tb_CPass = New Thesis1_V1.Watermark()
        Me.tb_Pass = New Thesis1_V1.Watermark()
        Me.tb_Username = New Thesis1_V1.Watermark()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.BunifuThinButton22 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.photo = New System.Windows.Forms.PictureBox()
        Me.cb_Gender = New System.Windows.Forms.ComboBox()
        Me.tb_Email = New Thesis1_V1.Watermark()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.tb_Address = New Thesis1_V1.Watermark()
        Me.tb_CN = New Thesis1_V1.Watermark()
        Me.tb_Age = New Thesis1_V1.Watermark()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.tb_Name = New Thesis1_V1.Watermark()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.pnl_Reports = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.pnl_About = New System.Windows.Forms.Panel()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.pnl_top = New System.Windows.Forms.Panel()
        Me.btn_analyzeBeans = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_UP = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_MPM = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_Reports = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_About = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.pnl_menu = New System.Windows.Forms.Panel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.pnl_MPM = New System.Windows.Forms.Panel()
        Me.tb_pm26 = New System.Windows.Forms.TextBox()
        Me.Label147 = New System.Windows.Forms.Label()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tb_pm25 = New System.Windows.Forms.TextBox()
        Me.tb_pm24 = New System.Windows.Forms.TextBox()
        Me.tb_pm23 = New System.Windows.Forms.TextBox()
        Me.tb_pm22 = New System.Windows.Forms.TextBox()
        Me.tb_pm21 = New System.Windows.Forms.TextBox()
        Me.tb_pm20 = New System.Windows.Forms.TextBox()
        Me.tb_pm19 = New System.Windows.Forms.TextBox()
        Me.tb_pm18 = New System.Windows.Forms.TextBox()
        Me.tb_pm17 = New System.Windows.Forms.TextBox()
        Me.tb_pm16 = New System.Windows.Forms.TextBox()
        Me.tb_pm15 = New System.Windows.Forms.TextBox()
        Me.tb_pm14 = New System.Windows.Forms.TextBox()
        Me.tb_pm13 = New System.Windows.Forms.TextBox()
        Me.tb_pm12 = New System.Windows.Forms.TextBox()
        Me.tb_pm11 = New System.Windows.Forms.TextBox()
        Me.tb_pm10 = New System.Windows.Forms.TextBox()
        Me.tb_pm9 = New System.Windows.Forms.TextBox()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.BunifuFlatButton1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.tb_pm8 = New System.Windows.Forms.TextBox()
        Me.tb_pm7 = New System.Windows.Forms.TextBox()
        Me.tb_pm6 = New System.Windows.Forms.TextBox()
        Me.tb_pm5 = New System.Windows.Forms.TextBox()
        Me.tb_pm4 = New System.Windows.Forms.TextBox()
        Me.tb_pm3 = New System.Windows.Forms.TextBox()
        Me.tb_pm2 = New System.Windows.Forms.TextBox()
        Me.tb_pm1 = New System.Windows.Forms.TextBox()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.lbgauge_Well = New System.Windows.Forms.Label()
        Me.lbgauge_Over = New System.Windows.Forms.Label()
        Me.lbgauge_Under = New System.Windows.Forms.Label()
        Me.lbgauge_Reject = New System.Windows.Forms.Label()
        Me.pnl_AB.SuspendLayout()
        Me.pnl_step3.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.pnl_step1.SuspendLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_step2.SuspendLayout()
        CType(Me.pb2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.pnl_UP.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.photo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_Reports.SuspendLayout()
        Me.pnl_About.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_top.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_menu.SuspendLayout()
        Me.pnl_MPM.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'pnl_AB
        '
        Me.pnl_AB.Controls.Add(Me.pnl_step3)
        Me.pnl_AB.Controls.Add(Me.pnl_step1)
        Me.pnl_AB.Controls.Add(Me.pnl_step2)
        Me.pnl_AB.Controls.Add(Me.btn_step1)
        Me.pnl_AB.Controls.Add(Me.btn_step3)
        Me.pnl_AB.Controls.Add(Me.btn_step2)
        Me.pnl_AB.Location = New System.Drawing.Point(245, 30)
        Me.pnl_AB.Name = "pnl_AB"
        Me.pnl_AB.Size = New System.Drawing.Size(783, 616)
        Me.pnl_AB.TabIndex = 4
        '
        'pnl_step3
        '
        Me.pnl_step3.Controls.Add(Me.lbgauge_Reject)
        Me.pnl_step3.Controls.Add(Me.lbgauge_Under)
        Me.pnl_step3.Controls.Add(Me.lbgauge_Over)
        Me.pnl_step3.Controls.Add(Me.lbgauge_Well)
        Me.pnl_step3.Controls.Add(Me.LinkLabel1)
        Me.pnl_step3.Controls.Add(Me.lbl_Ototal)
        Me.pnl_step3.Controls.Add(Me.BunifuFlatButton2)
        Me.pnl_step3.Controls.Add(Me.lbl_pm)
        Me.pnl_step3.Controls.Add(Me.Label21)
        Me.pnl_step3.Controls.Add(Me.Label22)
        Me.pnl_step3.Controls.Add(Me.Label23)
        Me.pnl_step3.Controls.Add(Me.Label24)
        Me.pnl_step3.Controls.Add(Me.Label25)
        Me.pnl_step3.Controls.Add(Me.gauge_Reject)
        Me.pnl_step3.Controls.Add(Me.gauge_Over)
        Me.pnl_step3.Controls.Add(Me.gauge_Well)
        Me.pnl_step3.Controls.Add(Me.gauge_Under)
        Me.pnl_step3.Controls.Add(Me.Label26)
        Me.pnl_step3.Controls.Add(Me.PictureBox7)
        Me.pnl_step3.Controls.Add(Me.Panel5)
        Me.pnl_step3.Location = New System.Drawing.Point(13, 67)
        Me.pnl_step3.Name = "pnl_step3"
        Me.pnl_step3.Size = New System.Drawing.Size(758, 539)
        Me.pnl_step3.TabIndex = 5
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.SeaGreen
        Me.LinkLabel1.Location = New System.Drawing.Point(241, 505)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(315, 22)
        Me.LinkLabel1.TabIndex = 53
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = " Try Another Set Of Beans Again ?"
        '
        'lbl_Ototal
        '
        Me.lbl_Ototal.AutoSize = True
        Me.lbl_Ototal.Font = New System.Drawing.Font("Century Gothic", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Ototal.ForeColor = System.Drawing.Color.SeaGreen
        Me.lbl_Ototal.Location = New System.Drawing.Point(280, 234)
        Me.lbl_Ototal.Name = "lbl_Ototal"
        Me.lbl_Ototal.Size = New System.Drawing.Size(208, 115)
        Me.lbl_Ototal.TabIndex = 52
        Me.lbl_Ototal.Text = "000"
        '
        'BunifuFlatButton2
        '
        Me.BunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton2.BorderRadius = 0
        Me.BunifuFlatButton2.ButtonText = "Show Results"
        Me.BunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton2.Iconimage = CType(resources.GetObject("BunifuFlatButton2.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton2.Iconimage_right = Nothing
        Me.BunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton2.Iconimage_Selected = Nothing
        Me.BunifuFlatButton2.IconMarginLeft = 0
        Me.BunifuFlatButton2.IconMarginRight = 0
        Me.BunifuFlatButton2.IconRightVisible = True
        Me.BunifuFlatButton2.IconRightZoom = 0.0R
        Me.BunifuFlatButton2.IconVisible = True
        Me.BunifuFlatButton2.IconZoom = 90.0R
        Me.BunifuFlatButton2.IsTab = False
        Me.BunifuFlatButton2.Location = New System.Drawing.Point(300, 450)
        Me.BunifuFlatButton2.Name = "BunifuFlatButton2"
        Me.BunifuFlatButton2.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.BunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton2.selected = False
        Me.BunifuFlatButton2.Size = New System.Drawing.Size(171, 41)
        Me.BunifuFlatButton2.TabIndex = 51
        Me.BunifuFlatButton2.Text = "Show Results"
        Me.BunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'lbl_pm
        '
        Me.lbl_pm.AutoSize = True
        Me.lbl_pm.BackColor = System.Drawing.Color.White
        Me.lbl_pm.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pm.ForeColor = System.Drawing.Color.Red
        Me.lbl_pm.Location = New System.Drawing.Point(356, 419)
        Me.lbl_pm.Name = "lbl_pm"
        Me.lbl_pm.Size = New System.Drawing.Size(48, 22)
        Me.lbl_pm.TabIndex = 49
        Me.lbl_pm.Text = "0.00"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.White
        Me.Label21.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label21.Location = New System.Drawing.Point(316, 395)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(138, 22)
        Me.Label21.TabIndex = 48
        Me.Label21.Text = "Price Multiplier"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.White
        Me.Label22.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label22.Location = New System.Drawing.Point(615, 504)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(68, 22)
        Me.Label22.TabIndex = 46
        Me.Label22.Text = "Reject"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.White
        Me.Label23.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label23.Location = New System.Drawing.Point(34, 504)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(175, 22)
        Me.Label23.TabIndex = 45
        Me.Label23.Text = "Under  Fermented"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.White
        Me.Label24.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label24.Location = New System.Drawing.Point(558, 205)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(168, 22)
        Me.Label24.TabIndex = 44
        Me.Label24.Text = "Over  Fermented"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.White
        Me.Label25.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label25.Location = New System.Drawing.Point(65, 210)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(155, 22)
        Me.Label25.TabIndex = 43
        Me.Label25.Text = "Well  Fermented"
        '
        'gauge_Reject
        '
        Me.gauge_Reject.BackgroundImage = CType(resources.GetObject("gauge_Reject.BackgroundImage"), System.Drawing.Image)
        Me.gauge_Reject.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.gauge_Reject.Location = New System.Drawing.Point(562, 384)
        Me.gauge_Reject.Margin = New System.Windows.Forms.Padding(6)
        Me.gauge_Reject.Name = "gauge_Reject"
        Me.gauge_Reject.ProgressBgColor = System.Drawing.Color.Gray
        Me.gauge_Reject.ProgressColor1 = System.Drawing.Color.DarkKhaki
        Me.gauge_Reject.ProgressColor2 = System.Drawing.Color.DarkKhaki
        Me.gauge_Reject.Size = New System.Drawing.Size(171, 114)
        Me.gauge_Reject.Suffix = ""
        Me.gauge_Reject.TabIndex = 42
        Me.gauge_Reject.Thickness = 30
        Me.gauge_Reject.Value = 0
        '
        'gauge_Over
        '
        Me.gauge_Over.BackgroundImage = CType(resources.GetObject("gauge_Over.BackgroundImage"), System.Drawing.Image)
        Me.gauge_Over.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.gauge_Over.Location = New System.Drawing.Point(556, 90)
        Me.gauge_Over.Margin = New System.Windows.Forms.Padding(6)
        Me.gauge_Over.Name = "gauge_Over"
        Me.gauge_Over.ProgressBgColor = System.Drawing.Color.Gray
        Me.gauge_Over.ProgressColor1 = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.gauge_Over.ProgressColor2 = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.gauge_Over.Size = New System.Drawing.Size(171, 114)
        Me.gauge_Over.Suffix = ""
        Me.gauge_Over.TabIndex = 41
        Me.gauge_Over.Thickness = 30
        Me.gauge_Over.Value = 0
        '
        'gauge_Well
        '
        Me.gauge_Well.BackgroundImage = CType(resources.GetObject("gauge_Well.BackgroundImage"), System.Drawing.Image)
        Me.gauge_Well.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.gauge_Well.Location = New System.Drawing.Point(58, 90)
        Me.gauge_Well.Margin = New System.Windows.Forms.Padding(6)
        Me.gauge_Well.Name = "gauge_Well"
        Me.gauge_Well.ProgressBgColor = System.Drawing.Color.Gray
        Me.gauge_Well.ProgressColor1 = System.Drawing.Color.SaddleBrown
        Me.gauge_Well.ProgressColor2 = System.Drawing.Color.SaddleBrown
        Me.gauge_Well.Size = New System.Drawing.Size(171, 114)
        Me.gauge_Well.Suffix = ""
        Me.gauge_Well.TabIndex = 40
        Me.gauge_Well.Thickness = 30
        Me.gauge_Well.Value = 0
        '
        'gauge_Under
        '
        Me.gauge_Under.BackgroundImage = CType(resources.GetObject("gauge_Under.BackgroundImage"), System.Drawing.Image)
        Me.gauge_Under.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.gauge_Under.Location = New System.Drawing.Point(38, 384)
        Me.gauge_Under.Margin = New System.Windows.Forms.Padding(6)
        Me.gauge_Under.Name = "gauge_Under"
        Me.gauge_Under.ProgressBgColor = System.Drawing.Color.Gray
        Me.gauge_Under.ProgressColor1 = System.Drawing.Color.Purple
        Me.gauge_Under.ProgressColor2 = System.Drawing.Color.Purple
        Me.gauge_Under.Size = New System.Drawing.Size(171, 114)
        Me.gauge_Under.Suffix = ""
        Me.gauge_Under.TabIndex = 39
        Me.gauge_Under.Thickness = 30
        Me.gauge_Under.Value = 0
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.White
        Me.Label26.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label26.Location = New System.Drawing.Point(240, 344)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(269, 25)
        Me.Label26.TabIndex = 38
        Me.Label26.Text = "TOTAL NUMBER OF BEANS"
        '
        'PictureBox7
        '
        Me.PictureBox7.BackgroundImage = CType(resources.GetObject("PictureBox7.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox7.ErrorImage = Nothing
        Me.PictureBox7.Location = New System.Drawing.Point(8, 3)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(98, 68)
        Me.PictureBox7.TabIndex = 19
        Me.PictureBox7.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel5.Controls.Add(Me.Label15)
        Me.Panel5.Location = New System.Drawing.Point(112, 3)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(640, 68)
        Me.Panel5.TabIndex = 18
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe Print", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(212, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(147, 62)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Results"
        '
        'pnl_step1
        '
        Me.pnl_step1.Controls.Add(Me.btn_capture)
        Me.pnl_step1.Controls.Add(Me.PictureBox9)
        Me.pnl_step1.Controls.Add(Me.btn_new)
        Me.pnl_step1.Controls.Add(Me.btn_cancel)
        Me.pnl_step1.Controls.Add(Me.btn_save)
        Me.pnl_step1.Controls.Add(Me.btn_start)
        Me.pnl_step1.Controls.Add(Me.TableLayoutPanel1)
        Me.pnl_step1.Controls.Add(Me.Panel3)
        Me.pnl_step1.Controls.Add(Me.PictureBox5)
        Me.pnl_step1.Location = New System.Drawing.Point(13, 67)
        Me.pnl_step1.Name = "pnl_step1"
        Me.pnl_step1.Size = New System.Drawing.Size(758, 539)
        Me.pnl_step1.TabIndex = 6
        '
        'btn_capture
        '
        Me.btn_capture.ActiveBorderThickness = 1
        Me.btn_capture.ActiveCornerRadius = 20
        Me.btn_capture.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_capture.ActiveForecolor = System.Drawing.Color.White
        Me.btn_capture.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_capture.BackColor = System.Drawing.Color.White
        Me.btn_capture.BackgroundImage = CType(resources.GetObject("btn_capture.BackgroundImage"), System.Drawing.Image)
        Me.btn_capture.ButtonText = "Capture"
        Me.btn_capture.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_capture.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_capture.ForeColor = System.Drawing.Color.SeaGreen
        Me.btn_capture.IdleBorderThickness = 1
        Me.btn_capture.IdleCornerRadius = 20
        Me.btn_capture.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_capture.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_capture.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_capture.Location = New System.Drawing.Point(300, 412)
        Me.btn_capture.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn_capture.Name = "btn_capture"
        Me.btn_capture.Size = New System.Drawing.Size(174, 111)
        Me.btn_capture.TabIndex = 24
        Me.btn_capture.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(320, 414)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(151, 109)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox9.TabIndex = 29
        Me.PictureBox9.TabStop = False
        '
        'btn_new
        '
        Me.btn_new.ActiveBorderThickness = 1
        Me.btn_new.ActiveCornerRadius = 20
        Me.btn_new.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_new.ActiveForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_new.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_new.BackColor = System.Drawing.Color.White
        Me.btn_new.BackgroundImage = CType(resources.GetObject("btn_new.BackgroundImage"), System.Drawing.Image)
        Me.btn_new.ButtonText = "New"
        Me.btn_new.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_new.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_new.ForeColor = System.Drawing.Color.SeaGreen
        Me.btn_new.IdleBorderThickness = 1
        Me.btn_new.IdleCornerRadius = 20
        Me.btn_new.IdleFillColor = System.Drawing.Color.White
        Me.btn_new.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_new.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_new.Location = New System.Drawing.Point(115, 470)
        Me.btn_new.Margin = New System.Windows.Forms.Padding(5)
        Me.btn_new.Name = "btn_new"
        Me.btn_new.Size = New System.Drawing.Size(139, 53)
        Me.btn_new.TabIndex = 28
        Me.btn_new.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_cancel
        '
        Me.btn_cancel.ActiveBorderThickness = 1
        Me.btn_cancel.ActiveCornerRadius = 20
        Me.btn_cancel.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_cancel.ActiveForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_cancel.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_cancel.BackColor = System.Drawing.Color.White
        Me.btn_cancel.BackgroundImage = CType(resources.GetObject("btn_cancel.BackgroundImage"), System.Drawing.Image)
        Me.btn_cancel.ButtonText = "Cancel"
        Me.btn_cancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_cancel.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_cancel.ForeColor = System.Drawing.Color.SeaGreen
        Me.btn_cancel.IdleBorderThickness = 1
        Me.btn_cancel.IdleCornerRadius = 20
        Me.btn_cancel.IdleFillColor = System.Drawing.Color.White
        Me.btn_cancel.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_cancel.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_cancel.Location = New System.Drawing.Point(506, 470)
        Me.btn_cancel.Margin = New System.Windows.Forms.Padding(5)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(139, 53)
        Me.btn_cancel.TabIndex = 27
        Me.btn_cancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_save
        '
        Me.btn_save.ActiveBorderThickness = 1
        Me.btn_save.ActiveCornerRadius = 20
        Me.btn_save.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_save.ActiveForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_save.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_save.BackColor = System.Drawing.Color.White
        Me.btn_save.BackgroundImage = CType(resources.GetObject("btn_save.BackgroundImage"), System.Drawing.Image)
        Me.btn_save.ButtonText = "Save"
        Me.btn_save.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_save.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_save.ForeColor = System.Drawing.Color.SeaGreen
        Me.btn_save.IdleBorderThickness = 1
        Me.btn_save.IdleCornerRadius = 20
        Me.btn_save.IdleFillColor = System.Drawing.Color.White
        Me.btn_save.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_save.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_save.Location = New System.Drawing.Point(506, 411)
        Me.btn_save.Margin = New System.Windows.Forms.Padding(5)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(139, 53)
        Me.btn_save.TabIndex = 26
        Me.btn_save.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_start
        '
        Me.btn_start.ActiveBorderThickness = 1
        Me.btn_start.ActiveCornerRadius = 20
        Me.btn_start.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_start.ActiveForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_start.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_start.BackColor = System.Drawing.Color.White
        Me.btn_start.BackgroundImage = CType(resources.GetObject("btn_start.BackgroundImage"), System.Drawing.Image)
        Me.btn_start.ButtonText = "Start"
        Me.btn_start.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_start.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_start.ForeColor = System.Drawing.Color.SeaGreen
        Me.btn_start.IdleBorderThickness = 1
        Me.btn_start.IdleCornerRadius = 20
        Me.btn_start.IdleFillColor = System.Drawing.Color.White
        Me.btn_start.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_start.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_start.Location = New System.Drawing.Point(115, 414)
        Me.btn_start.Margin = New System.Windows.Forms.Padding(5)
        Me.btn_start.Name = "btn_start"
        Me.btn_start.Size = New System.Drawing.Size(139, 53)
        Me.btn_start.TabIndex = 25
        Me.btn_start.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.PictureBox8, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.PictureBox10, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(17, 79)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(725, 315)
        Me.TableLayoutPanel1.TabIndex = 17
        '
        'PictureBox8
        '
        Me.PictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox8.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(356, 309)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox8.TabIndex = 0
        Me.PictureBox8.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox10.Location = New System.Drawing.Point(365, 3)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(357, 309)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox10.TabIndex = 1
        Me.PictureBox10.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Location = New System.Drawing.Point(112, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(640, 68)
        Me.Panel3.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe Print", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(71, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(489, 65)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Capture and Save Image"
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = CType(resources.GetObject("PictureBox5.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.ErrorImage = Nothing
        Me.PictureBox5.Location = New System.Drawing.Point(8, 3)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(98, 68)
        Me.PictureBox5.TabIndex = 15
        Me.PictureBox5.TabStop = False
        '
        'pnl_step2
        '
        Me.pnl_step2.Controls.Add(Me.Label20)
        Me.pnl_step2.Controls.Add(Me.Label19)
        Me.pnl_step2.Controls.Add(Me.BunifuProgressBar1)
        Me.pnl_step2.Controls.Add(Me.BunifuThinButton21)
        Me.pnl_step2.Controls.Add(Me.Label18)
        Me.pnl_step2.Controls.Add(Me.Label17)
        Me.pnl_step2.Controls.Add(Me.Label16)
        Me.pnl_step2.Controls.Add(Me.pb2)
        Me.pnl_step2.Controls.Add(Me.pb1)
        Me.pnl_step2.Controls.Add(Me.pb0)
        Me.pnl_step2.Controls.Add(Me.PictureBox6)
        Me.pnl_step2.Controls.Add(Me.Panel4)
        Me.pnl_step2.Location = New System.Drawing.Point(13, 67)
        Me.pnl_step2.Name = "pnl_step2"
        Me.pnl_step2.Size = New System.Drawing.Size(758, 539)
        Me.pnl_step2.TabIndex = 6
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(379, 391)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(25, 17)
        Me.Label20.TabIndex = 28
        Me.Label20.Text = "0%"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(17, 391)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(99, 17)
        Me.Label19.TabIndex = 27
        Me.Label19.Text = "Please Wait ..."
        '
        'BunifuProgressBar1
        '
        Me.BunifuProgressBar1.BackColor = System.Drawing.Color.Silver
        Me.BunifuProgressBar1.BorderRadius = 5
        Me.BunifuProgressBar1.Location = New System.Drawing.Point(20, 411)
        Me.BunifuProgressBar1.MaximumValue = 100
        Me.BunifuProgressBar1.Name = "BunifuProgressBar1"
        Me.BunifuProgressBar1.ProgressColor = System.Drawing.Color.SeaGreen
        Me.BunifuProgressBar1.Size = New System.Drawing.Size(720, 10)
        Me.BunifuProgressBar1.TabIndex = 26
        Me.BunifuProgressBar1.Value = 0
        '
        'BunifuThinButton21
        '
        Me.BunifuThinButton21.ActiveBorderThickness = 1
        Me.BunifuThinButton21.ActiveCornerRadius = 20
        Me.BunifuThinButton21.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BunifuThinButton21.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton21.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BunifuThinButton21.BackColor = System.Drawing.Color.White
        Me.BunifuThinButton21.BackgroundImage = CType(resources.GetObject("BunifuThinButton21.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton21.ButtonText = "Analyze Images"
        Me.BunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton21.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton21.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton21.IdleBorderThickness = 1
        Me.BunifuThinButton21.IdleCornerRadius = 20
        Me.BunifuThinButton21.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BunifuThinButton21.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuThinButton21.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BunifuThinButton21.Location = New System.Drawing.Point(282, 443)
        Me.BunifuThinButton21.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BunifuThinButton21.Name = "BunifuThinButton21"
        Me.BunifuThinButton21.Size = New System.Drawing.Size(210, 69)
        Me.BunifuThinButton21.TabIndex = 25
        Me.BunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(585, 329)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(103, 21)
        Me.Label18.TabIndex = 24
        Me.Label18.Text = "Third Image"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(316, 329)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(125, 21)
        Me.Label17.TabIndex = 23
        Me.Label17.Text = "Second Image"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(75, 329)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(95, 21)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "First Image"
        '
        'pb2
        '
        Me.pb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pb2.Location = New System.Drawing.Point(519, 102)
        Me.pb2.Name = "pb2"
        Me.pb2.Size = New System.Drawing.Size(220, 224)
        Me.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pb2.TabIndex = 21
        Me.pb2.TabStop = False
        '
        'pb1
        '
        Me.pb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pb1.Location = New System.Drawing.Point(272, 102)
        Me.pb1.Name = "pb1"
        Me.pb1.Size = New System.Drawing.Size(220, 224)
        Me.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pb1.TabIndex = 20
        Me.pb1.TabStop = False
        '
        'pb0
        '
        Me.pb0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pb0.Location = New System.Drawing.Point(20, 102)
        Me.pb0.Name = "pb0"
        Me.pb0.Size = New System.Drawing.Size(220, 224)
        Me.pb0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pb0.TabIndex = 19
        Me.pb0.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox6.ErrorImage = Nothing
        Me.PictureBox6.Location = New System.Drawing.Point(8, 3)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(98, 68)
        Me.PictureBox6.TabIndex = 18
        Me.PictureBox6.TabStop = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel4.Controls.Add(Me.Label13)
        Me.Panel4.Location = New System.Drawing.Point(112, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(640, 68)
        Me.Panel4.TabIndex = 17
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe Print", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(78, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(461, 62)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Load and Analyze Image"
        '
        'btn_step1
        '
        Me.btn_step1.ActiveBorderThickness = 1
        Me.btn_step1.ActiveCornerRadius = 20
        Me.btn_step1.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.btn_step1.ActiveForecolor = System.Drawing.Color.White
        Me.btn_step1.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.btn_step1.BackColor = System.Drawing.Color.White
        Me.btn_step1.BackgroundImage = CType(resources.GetObject("btn_step1.BackgroundImage"), System.Drawing.Image)
        Me.btn_step1.ButtonText = "Step One"
        Me.btn_step1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_step1.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_step1.ForeColor = System.Drawing.Color.SeaGreen
        Me.btn_step1.IdleBorderThickness = 1
        Me.btn_step1.IdleCornerRadius = 20
        Me.btn_step1.IdleFillColor = System.Drawing.Color.White
        Me.btn_step1.IdleForecolor = System.Drawing.Color.SeaGreen
        Me.btn_step1.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.btn_step1.Location = New System.Drawing.Point(44, 16)
        Me.btn_step1.Margin = New System.Windows.Forms.Padding(5)
        Me.btn_step1.Name = "btn_step1"
        Me.btn_step1.Size = New System.Drawing.Size(184, 40)
        Me.btn_step1.TabIndex = 4
        Me.btn_step1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_step3
        '
        Me.btn_step3.ActiveBorderThickness = 1
        Me.btn_step3.ActiveCornerRadius = 20
        Me.btn_step3.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.btn_step3.ActiveForecolor = System.Drawing.Color.White
        Me.btn_step3.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.btn_step3.BackColor = System.Drawing.Color.White
        Me.btn_step3.BackgroundImage = CType(resources.GetObject("btn_step3.BackgroundImage"), System.Drawing.Image)
        Me.btn_step3.ButtonText = "Step Three"
        Me.btn_step3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_step3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_step3.ForeColor = System.Drawing.Color.SeaGreen
        Me.btn_step3.IdleBorderThickness = 1
        Me.btn_step3.IdleCornerRadius = 20
        Me.btn_step3.IdleFillColor = System.Drawing.Color.White
        Me.btn_step3.IdleForecolor = System.Drawing.Color.SeaGreen
        Me.btn_step3.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.btn_step3.Location = New System.Drawing.Point(538, 16)
        Me.btn_step3.Margin = New System.Windows.Forms.Padding(5)
        Me.btn_step3.Name = "btn_step3"
        Me.btn_step3.Size = New System.Drawing.Size(184, 40)
        Me.btn_step3.TabIndex = 3
        Me.btn_step3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_step2
        '
        Me.btn_step2.ActiveBorderThickness = 1
        Me.btn_step2.ActiveCornerRadius = 20
        Me.btn_step2.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.btn_step2.ActiveForecolor = System.Drawing.Color.White
        Me.btn_step2.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.btn_step2.BackColor = System.Drawing.Color.White
        Me.btn_step2.BackgroundImage = CType(resources.GetObject("btn_step2.BackgroundImage"), System.Drawing.Image)
        Me.btn_step2.ButtonText = "Step Two"
        Me.btn_step2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_step2.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_step2.ForeColor = System.Drawing.Color.SeaGreen
        Me.btn_step2.IdleBorderThickness = 1
        Me.btn_step2.IdleCornerRadius = 20
        Me.btn_step2.IdleFillColor = System.Drawing.Color.White
        Me.btn_step2.IdleForecolor = System.Drawing.Color.SeaGreen
        Me.btn_step2.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.btn_step2.Location = New System.Drawing.Point(285, 16)
        Me.btn_step2.Margin = New System.Windows.Forms.Padding(5)
        Me.btn_step2.Name = "btn_step2"
        Me.btn_step2.Size = New System.Drawing.Size(184, 40)
        Me.btn_step2.TabIndex = 2
        Me.btn_step2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_UP
        '
        Me.pnl_UP.Controls.Add(Me.lbl_ID)
        Me.pnl_UP.Controls.Add(Me.DataGridView1)
        Me.pnl_UP.Controls.Add(Me.Panel1)
        Me.pnl_UP.Controls.Add(Me.Label27)
        Me.pnl_UP.Location = New System.Drawing.Point(245, 30)
        Me.pnl_UP.Name = "pnl_UP"
        Me.pnl_UP.Size = New System.Drawing.Size(771, 616)
        Me.pnl_UP.TabIndex = 5
        '
        'lbl_ID
        '
        Me.lbl_ID.AutoSize = True
        Me.lbl_ID.Location = New System.Drawing.Point(18, 51)
        Me.lbl_ID.Name = "lbl_ID"
        Me.lbl_ID.Size = New System.Drawing.Size(18, 13)
        Me.lbl_ID.TabIndex = 93
        Me.lbl_ID.Text = "ID"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.SeaGreen
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.ColumnHeadersHeight = 25
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column5, Me.Column2, Me.Column3, Me.Column4})
        Me.DataGridView1.Cursor = System.Windows.Forms.Cursors.Hand
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.GridColor = System.Drawing.Color.White
        Me.DataGridView1.Location = New System.Drawing.Point(13, 411)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.Color.SeaGreen
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(749, 195)
        Me.DataGridView1.TabIndex = 64
        '
        'Column1
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.SeaGreen
        Me.Column1.DefaultCellStyle = DataGridViewCellStyle3
        Me.Column1.HeaderText = "User ID"
        Me.Column1.Name = "Column1"
        '
        'Column5
        '
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.SeaGreen
        Me.Column5.DefaultCellStyle = DataGridViewCellStyle4
        Me.Column5.HeaderText = "Name"
        Me.Column5.Name = "Column5"
        '
        'Column2
        '
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.SeaGreen
        Me.Column2.DefaultCellStyle = DataGridViewCellStyle5
        Me.Column2.HeaderText = "Gender"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.SeaGreen
        Me.Column3.DefaultCellStyle = DataGridViewCellStyle6
        Me.Column3.HeaderText = "Address"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.SeaGreen
        Me.Column4.DefaultCellStyle = DataGridViewCellStyle7
        Me.Column4.HeaderText = "Username"
        Me.Column4.Name = "Column4"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label148)
        Me.Panel1.Controls.Add(Me.BunifuThinButton26)
        Me.Panel1.Controls.Add(Me.BunifuThinButton25)
        Me.Panel1.Controls.Add(Me.BunifuThinButton24)
        Me.Panel1.Controls.Add(Me.BunifuThinButton23)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.tb_CPass)
        Me.Panel1.Controls.Add(Me.tb_Pass)
        Me.Panel1.Controls.Add(Me.tb_Username)
        Me.Panel1.Controls.Add(Me.Label34)
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Controls.Add(Me.BunifuThinButton22)
        Me.Panel1.Controls.Add(Me.photo)
        Me.Panel1.Controls.Add(Me.cb_Gender)
        Me.Panel1.Controls.Add(Me.tb_Email)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.tb_Address)
        Me.Panel1.Controls.Add(Me.tb_CN)
        Me.Panel1.Controls.Add(Me.tb_Age)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label31)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.tb_Name)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Location = New System.Drawing.Point(13, 67)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(749, 340)
        Me.Panel1.TabIndex = 1
        '
        'Label148
        '
        Me.Label148.AutoSize = True
        Me.Label148.Font = New System.Drawing.Font("Century Gothic", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label148.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label148.Location = New System.Drawing.Point(3, 2)
        Me.Label148.Name = "Label148"
        Me.Label148.Size = New System.Drawing.Size(220, 25)
        Me.Label148.TabIndex = 92
        Me.Label148.Text = "Personal Information"
        '
        'BunifuThinButton26
        '
        Me.BunifuThinButton26.ActiveBorderThickness = 1
        Me.BunifuThinButton26.ActiveCornerRadius = 20
        Me.BunifuThinButton26.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton26.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton26.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton26.BackColor = System.Drawing.Color.White
        Me.BunifuThinButton26.BackgroundImage = CType(resources.GetObject("BunifuThinButton26.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton26.ButtonText = "Delete"
        Me.BunifuThinButton26.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton26.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton26.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton26.IdleBorderThickness = 1
        Me.BunifuThinButton26.IdleCornerRadius = 20
        Me.BunifuThinButton26.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton26.IdleForecolor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton26.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton26.Location = New System.Drawing.Point(618, 287)
        Me.BunifuThinButton26.Margin = New System.Windows.Forms.Padding(5)
        Me.BunifuThinButton26.Name = "BunifuThinButton26"
        Me.BunifuThinButton26.Size = New System.Drawing.Size(108, 44)
        Me.BunifuThinButton26.TabIndex = 91
        Me.BunifuThinButton26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton25
        '
        Me.BunifuThinButton25.ActiveBorderThickness = 1
        Me.BunifuThinButton25.ActiveCornerRadius = 20
        Me.BunifuThinButton25.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton25.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton25.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton25.BackColor = System.Drawing.Color.White
        Me.BunifuThinButton25.BackgroundImage = CType(resources.GetObject("BunifuThinButton25.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton25.ButtonText = "Update"
        Me.BunifuThinButton25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton25.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton25.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton25.IdleBorderThickness = 1
        Me.BunifuThinButton25.IdleCornerRadius = 20
        Me.BunifuThinButton25.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton25.IdleForecolor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton25.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton25.Location = New System.Drawing.Point(486, 287)
        Me.BunifuThinButton25.Margin = New System.Windows.Forms.Padding(5)
        Me.BunifuThinButton25.Name = "BunifuThinButton25"
        Me.BunifuThinButton25.Size = New System.Drawing.Size(108, 44)
        Me.BunifuThinButton25.TabIndex = 90
        Me.BunifuThinButton25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton24
        '
        Me.BunifuThinButton24.ActiveBorderThickness = 1
        Me.BunifuThinButton24.ActiveCornerRadius = 20
        Me.BunifuThinButton24.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton24.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton24.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton24.BackColor = System.Drawing.Color.White
        Me.BunifuThinButton24.BackgroundImage = CType(resources.GetObject("BunifuThinButton24.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton24.ButtonText = "Save"
        Me.BunifuThinButton24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton24.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton24.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton24.IdleBorderThickness = 1
        Me.BunifuThinButton24.IdleCornerRadius = 20
        Me.BunifuThinButton24.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton24.IdleForecolor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton24.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton24.Location = New System.Drawing.Point(618, 248)
        Me.BunifuThinButton24.Margin = New System.Windows.Forms.Padding(5)
        Me.BunifuThinButton24.Name = "BunifuThinButton24"
        Me.BunifuThinButton24.Size = New System.Drawing.Size(108, 44)
        Me.BunifuThinButton24.TabIndex = 89
        Me.BunifuThinButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton23
        '
        Me.BunifuThinButton23.ActiveBorderThickness = 1
        Me.BunifuThinButton23.ActiveCornerRadius = 20
        Me.BunifuThinButton23.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton23.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton23.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton23.BackColor = System.Drawing.Color.White
        Me.BunifuThinButton23.BackgroundImage = CType(resources.GetObject("BunifuThinButton23.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton23.ButtonText = "New"
        Me.BunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton23.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton23.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton23.IdleBorderThickness = 1
        Me.BunifuThinButton23.IdleCornerRadius = 20
        Me.BunifuThinButton23.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton23.IdleForecolor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton23.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton23.Location = New System.Drawing.Point(486, 248)
        Me.BunifuThinButton23.Margin = New System.Windows.Forms.Padding(5)
        Me.BunifuThinButton23.Name = "BunifuThinButton23"
        Me.BunifuThinButton23.Size = New System.Drawing.Size(108, 44)
        Me.BunifuThinButton23.TabIndex = 88
        Me.BunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(3, 301)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(147, 21)
        Me.Label35.TabIndex = 87
        Me.Label35.Text = "Confirm Password"
        '
        'tb_CPass
        '
        Me.tb_CPass.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_CPass.Location = New System.Drawing.Point(156, 298)
        Me.tb_CPass.Name = "tb_CPass"
        Me.tb_CPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.tb_CPass.Size = New System.Drawing.Size(219, 27)
        Me.tb_CPass.TabIndex = 86
        Me.tb_CPass.WatermarkColor = System.Drawing.Color.Gray
        Me.tb_CPass.WatermarkText = "Enter Your Password"
        '
        'tb_Pass
        '
        Me.tb_Pass.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_Pass.Location = New System.Drawing.Point(156, 267)
        Me.tb_Pass.Name = "tb_Pass"
        Me.tb_Pass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.tb_Pass.Size = New System.Drawing.Size(219, 27)
        Me.tb_Pass.TabIndex = 85
        Me.tb_Pass.WatermarkColor = System.Drawing.Color.Gray
        Me.tb_Pass.WatermarkText = "Enter Your Password"
        '
        'tb_Username
        '
        Me.tb_Username.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_Username.Location = New System.Drawing.Point(156, 234)
        Me.tb_Username.Name = "tb_Username"
        Me.tb_Username.Size = New System.Drawing.Size(219, 27)
        Me.tb_Username.TabIndex = 84
        Me.tb_Username.WatermarkColor = System.Drawing.Color.Gray
        Me.tb_Username.WatermarkText = "Enter Your Username"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(64, 273)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(82, 21)
        Me.Label34.TabIndex = 83
        Me.Label34.Text = "Password"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(62, 240)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(88, 21)
        Me.Label33.TabIndex = 82
        Me.Label33.Text = "Username"
        '
        'BunifuThinButton22
        '
        Me.BunifuThinButton22.ActiveBorderThickness = 1
        Me.BunifuThinButton22.ActiveCornerRadius = 20
        Me.BunifuThinButton22.ActiveFillColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton22.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton22.ActiveLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton22.BackColor = System.Drawing.Color.White
        Me.BunifuThinButton22.BackgroundImage = CType(resources.GetObject("BunifuThinButton22.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton22.ButtonText = "Add Photo"
        Me.BunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton22.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuThinButton22.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton22.IdleBorderThickness = 1
        Me.BunifuThinButton22.IdleCornerRadius = 20
        Me.BunifuThinButton22.IdleFillColor = System.Drawing.Color.White
        Me.BunifuThinButton22.IdleForecolor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton22.IdleLineColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton22.Location = New System.Drawing.Point(520, 188)
        Me.BunifuThinButton22.Margin = New System.Windows.Forms.Padding(5)
        Me.BunifuThinButton22.Name = "BunifuThinButton22"
        Me.BunifuThinButton22.Size = New System.Drawing.Size(157, 38)
        Me.BunifuThinButton22.TabIndex = 81
        Me.BunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'photo
        '
        Me.photo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.photo.Location = New System.Drawing.Point(486, 15)
        Me.photo.Name = "photo"
        Me.photo.Size = New System.Drawing.Size(209, 170)
        Me.photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.photo.TabIndex = 80
        Me.photo.TabStop = False
        '
        'cb_Gender
        '
        Me.cb_Gender.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb_Gender.FormattingEnabled = True
        Me.cb_Gender.Items.AddRange(New Object() {"", "Male", "Female"})
        Me.cb_Gender.Location = New System.Drawing.Point(155, 103)
        Me.cb_Gender.Name = "cb_Gender"
        Me.cb_Gender.Size = New System.Drawing.Size(219, 29)
        Me.cb_Gender.TabIndex = 79
        '
        'tb_Email
        '
        Me.tb_Email.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_Email.Location = New System.Drawing.Point(156, 203)
        Me.tb_Email.Name = "tb_Email"
        Me.tb_Email.Size = New System.Drawing.Size(219, 27)
        Me.tb_Email.TabIndex = 78
        Me.tb_Email.WatermarkColor = System.Drawing.Color.Gray
        Me.tb_Email.WatermarkText = "Enter Your eMail"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(98, 209)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(52, 21)
        Me.Label29.TabIndex = 77
        Me.Label29.Text = "eMail"
        '
        'tb_Address
        '
        Me.tb_Address.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_Address.Location = New System.Drawing.Point(156, 170)
        Me.tb_Address.Name = "tb_Address"
        Me.tb_Address.Size = New System.Drawing.Size(219, 27)
        Me.tb_Address.TabIndex = 76
        Me.tb_Address.WatermarkColor = System.Drawing.Color.Gray
        Me.tb_Address.WatermarkText = "Enter Your Address"
        '
        'tb_CN
        '
        Me.tb_CN.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_CN.Location = New System.Drawing.Point(156, 139)
        Me.tb_CN.Name = "tb_CN"
        Me.tb_CN.Size = New System.Drawing.Size(219, 27)
        Me.tb_CN.TabIndex = 75
        Me.tb_CN.WatermarkColor = System.Drawing.Color.Gray
        Me.tb_CN.WatermarkText = "Enter Your Contact #"
        '
        'tb_Age
        '
        Me.tb_Age.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_Age.Location = New System.Drawing.Point(156, 70)
        Me.tb_Age.Name = "tb_Age"
        Me.tb_Age.Size = New System.Drawing.Size(219, 27)
        Me.tb_Age.TabIndex = 73
        Me.tb_Age.WatermarkColor = System.Drawing.Color.Gray
        Me.tb_Age.WatermarkText = "Enter Your Age"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(78, 173)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(72, 21)
        Me.Label28.TabIndex = 72
        Me.Label28.Text = "Address"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(46, 142)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 21)
        Me.Label8.TabIndex = 71
        Me.Label8.Text = "Contact No"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(102, 74)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(44, 21)
        Me.Label31.TabIndex = 70
        Me.Label31.Text = "Age"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(76, 108)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(70, 21)
        Me.Label32.TabIndex = 69
        Me.Label32.Text = "Gender"
        '
        'tb_Name
        '
        Me.tb_Name.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_Name.Location = New System.Drawing.Point(155, 37)
        Me.tb_Name.Name = "tb_Name"
        Me.tb_Name.Size = New System.Drawing.Size(219, 27)
        Me.tb_Name.TabIndex = 68
        Me.tb_Name.WatermarkColor = System.Drawing.Color.Gray
        Me.tb_Name.WatermarkText = "Enter Your Name"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(92, 42)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(58, 21)
        Me.Label30.TabIndex = 63
        Me.Label30.Text = "Name"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Segoe Print", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label27.Location = New System.Drawing.Point(444, 8)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(324, 62)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "Create New User"
        '
        'pnl_Reports
        '
        Me.pnl_Reports.Controls.Add(Me.Label10)
        Me.pnl_Reports.Location = New System.Drawing.Point(245, 30)
        Me.pnl_Reports.Name = "pnl_Reports"
        Me.pnl_Reports.Size = New System.Drawing.Size(783, 616)
        Me.pnl_Reports.TabIndex = 7
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(26, 20)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(66, 21)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Panel 4"
        '
        'pnl_About
        '
        Me.pnl_About.Controls.Add(Me.Label144)
        Me.pnl_About.Controls.Add(Me.Label143)
        Me.pnl_About.Controls.Add(Me.Label142)
        Me.pnl_About.Controls.Add(Me.Label141)
        Me.pnl_About.Controls.Add(Me.Label12)
        Me.pnl_About.Controls.Add(Me.RichTextBox1)
        Me.pnl_About.Location = New System.Drawing.Point(245, 30)
        Me.pnl_About.Name = "pnl_About"
        Me.pnl_About.Size = New System.Drawing.Size(783, 616)
        Me.pnl_About.TabIndex = 8
        '
        'Label144
        '
        Me.Label144.AutoSize = True
        Me.Label144.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label144.Location = New System.Drawing.Point(295, 514)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(192, 24)
        Me.Label144.TabIndex = 56
        Me.Label144.Text = "Ma. Paula Estrada"
        '
        'Label143
        '
        Me.Label143.AutoSize = True
        Me.Label143.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label143.Location = New System.Drawing.Point(273, 484)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(234, 24)
        Me.Label143.TabIndex = 55
        Me.Label143.Text = "Angel Vonn Capuyan"
        '
        'Label142
        '
        Me.Label142.AutoSize = True
        Me.Label142.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label142.Location = New System.Drawing.Point(306, 458)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(160, 24)
        Me.Label142.TabIndex = 54
        Me.Label142.Text = "Kevin A. Mendi"
        '
        'Label141
        '
        Me.Label141.AutoSize = True
        Me.Label141.Font = New System.Drawing.Font("Segoe Print", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label141.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label141.Location = New System.Drawing.Point(241, 389)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(281, 62)
        Me.Label141.TabIndex = 10
        Me.Label141.Text = "~ Developer ~"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe Print", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label12.Location = New System.Drawing.Point(165, 44)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(437, 62)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "~ About This Project ~"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.White
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.ForeColor = System.Drawing.Color.Black
        Me.RichTextBox1.Location = New System.Drawing.Point(80, 121)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(617, 223)
        Me.RichTextBox1.TabIndex = 8
        Me.RichTextBox1.Text = resources.GetString("RichTextBox1.Text")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(1174, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(26, 25)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "X"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.ErrorImage = Nothing
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(31, 26)
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 15.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(37, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 23)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Thesis_V1"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(1006, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(28, 27)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "X"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label14.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(975, -1)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(25, 27)
        Me.Label14.TabIndex = 7
        Me.Label14.Text = "_"
        '
        'pnl_top
        '
        Me.pnl_top.BackColor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.pnl_top.Controls.Add(Me.Label14)
        Me.pnl_top.Controls.Add(Me.Label11)
        Me.pnl_top.Controls.Add(Me.Label2)
        Me.pnl_top.Controls.Add(Me.PictureBox1)
        Me.pnl_top.Controls.Add(Me.Label1)
        Me.pnl_top.Location = New System.Drawing.Point(0, 0)
        Me.pnl_top.Name = "pnl_top"
        Me.pnl_top.Size = New System.Drawing.Size(1034, 26)
        Me.pnl_top.TabIndex = 3
        '
        'btn_analyzeBeans
        '
        Me.btn_analyzeBeans.Activecolor = System.Drawing.Color.SeaGreen
        Me.btn_analyzeBeans.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_analyzeBeans.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_analyzeBeans.BorderRadius = 0
        Me.btn_analyzeBeans.ButtonText = "Analyze Beans"
        Me.btn_analyzeBeans.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_analyzeBeans.DisabledColor = System.Drawing.Color.Gray
        Me.btn_analyzeBeans.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_analyzeBeans.Iconimage = CType(resources.GetObject("btn_analyzeBeans.Iconimage"), System.Drawing.Image)
        Me.btn_analyzeBeans.Iconimage_right = Nothing
        Me.btn_analyzeBeans.Iconimage_right_Selected = Nothing
        Me.btn_analyzeBeans.Iconimage_Selected = Nothing
        Me.btn_analyzeBeans.IconMarginLeft = 0
        Me.btn_analyzeBeans.IconMarginRight = 0
        Me.btn_analyzeBeans.IconRightVisible = True
        Me.btn_analyzeBeans.IconRightZoom = 0.0R
        Me.btn_analyzeBeans.IconVisible = True
        Me.btn_analyzeBeans.IconZoom = 90.0R
        Me.btn_analyzeBeans.IsTab = False
        Me.btn_analyzeBeans.Location = New System.Drawing.Point(0, 255)
        Me.btn_analyzeBeans.Name = "btn_analyzeBeans"
        Me.btn_analyzeBeans.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_analyzeBeans.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_analyzeBeans.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_analyzeBeans.selected = False
        Me.btn_analyzeBeans.Size = New System.Drawing.Size(239, 48)
        Me.btn_analyzeBeans.TabIndex = 4
        Me.btn_analyzeBeans.Text = "Analyze Beans"
        Me.btn_analyzeBeans.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_analyzeBeans.Textcolor = System.Drawing.Color.White
        Me.btn_analyzeBeans.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_UP
        '
        Me.btn_UP.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btn_UP.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_UP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_UP.BorderRadius = 0
        Me.btn_UP.ButtonText = "Users Profile"
        Me.btn_UP.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_UP.DisabledColor = System.Drawing.Color.Gray
        Me.btn_UP.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_UP.Iconimage = CType(resources.GetObject("btn_UP.Iconimage"), System.Drawing.Image)
        Me.btn_UP.Iconimage_right = Nothing
        Me.btn_UP.Iconimage_right_Selected = Nothing
        Me.btn_UP.Iconimage_Selected = Nothing
        Me.btn_UP.IconMarginLeft = 0
        Me.btn_UP.IconMarginRight = 0
        Me.btn_UP.IconRightVisible = True
        Me.btn_UP.IconRightZoom = 0.0R
        Me.btn_UP.IconVisible = True
        Me.btn_UP.IconZoom = 90.0R
        Me.btn_UP.IsTab = False
        Me.btn_UP.Location = New System.Drawing.Point(0, 309)
        Me.btn_UP.Name = "btn_UP"
        Me.btn_UP.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_UP.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_UP.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_UP.selected = False
        Me.btn_UP.Size = New System.Drawing.Size(239, 48)
        Me.btn_UP.TabIndex = 5
        Me.btn_UP.Text = "Users Profile"
        Me.btn_UP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_UP.Textcolor = System.Drawing.Color.White
        Me.btn_UP.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_MPM
        '
        Me.btn_MPM.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btn_MPM.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_MPM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_MPM.BorderRadius = 0
        Me.btn_MPM.ButtonText = "Manage Price Matrix"
        Me.btn_MPM.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_MPM.DisabledColor = System.Drawing.Color.Gray
        Me.btn_MPM.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_MPM.Iconimage = CType(resources.GetObject("btn_MPM.Iconimage"), System.Drawing.Image)
        Me.btn_MPM.Iconimage_right = Nothing
        Me.btn_MPM.Iconimage_right_Selected = Nothing
        Me.btn_MPM.Iconimage_Selected = Nothing
        Me.btn_MPM.IconMarginLeft = 0
        Me.btn_MPM.IconMarginRight = 0
        Me.btn_MPM.IconRightVisible = True
        Me.btn_MPM.IconRightZoom = 0.0R
        Me.btn_MPM.IconVisible = True
        Me.btn_MPM.IconZoom = 90.0R
        Me.btn_MPM.IsTab = False
        Me.btn_MPM.Location = New System.Drawing.Point(3, 363)
        Me.btn_MPM.Name = "btn_MPM"
        Me.btn_MPM.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_MPM.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_MPM.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_MPM.selected = False
        Me.btn_MPM.Size = New System.Drawing.Size(239, 48)
        Me.btn_MPM.TabIndex = 6
        Me.btn_MPM.Text = "Manage Price Matrix"
        Me.btn_MPM.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_MPM.Textcolor = System.Drawing.Color.White
        Me.btn_MPM.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_Reports
        '
        Me.btn_Reports.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btn_Reports.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_Reports.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Reports.BorderRadius = 0
        Me.btn_Reports.ButtonText = "Log Out"
        Me.btn_Reports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Reports.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Reports.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Reports.Iconimage = CType(resources.GetObject("btn_Reports.Iconimage"), System.Drawing.Image)
        Me.btn_Reports.Iconimage_right = Nothing
        Me.btn_Reports.Iconimage_right_Selected = Nothing
        Me.btn_Reports.Iconimage_Selected = Nothing
        Me.btn_Reports.IconMarginLeft = 0
        Me.btn_Reports.IconMarginRight = 0
        Me.btn_Reports.IconRightVisible = True
        Me.btn_Reports.IconRightZoom = 0.0R
        Me.btn_Reports.IconVisible = True
        Me.btn_Reports.IconZoom = 90.0R
        Me.btn_Reports.IsTab = False
        Me.btn_Reports.Location = New System.Drawing.Point(3, 471)
        Me.btn_Reports.Name = "btn_Reports"
        Me.btn_Reports.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_Reports.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_Reports.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Reports.selected = False
        Me.btn_Reports.Size = New System.Drawing.Size(239, 48)
        Me.btn_Reports.TabIndex = 7
        Me.btn_Reports.Text = "Log Out"
        Me.btn_Reports.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Reports.Textcolor = System.Drawing.Color.White
        Me.btn_Reports.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_About
        '
        Me.btn_About.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btn_About.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_About.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_About.BorderRadius = 0
        Me.btn_About.ButtonText = "About"
        Me.btn_About.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_About.DisabledColor = System.Drawing.Color.Gray
        Me.btn_About.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_About.Iconimage = CType(resources.GetObject("btn_About.Iconimage"), System.Drawing.Image)
        Me.btn_About.Iconimage_right = Nothing
        Me.btn_About.Iconimage_right_Selected = Nothing
        Me.btn_About.Iconimage_Selected = Nothing
        Me.btn_About.IconMarginLeft = 0
        Me.btn_About.IconMarginRight = 0
        Me.btn_About.IconRightVisible = True
        Me.btn_About.IconRightZoom = 0.0R
        Me.btn_About.IconVisible = True
        Me.btn_About.IconZoom = 90.0R
        Me.btn_About.IsTab = False
        Me.btn_About.Location = New System.Drawing.Point(0, 417)
        Me.btn_About.Name = "btn_About"
        Me.btn_About.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_About.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(79, Byte), Integer), CType(CType(39, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_About.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_About.selected = False
        Me.btn_About.Size = New System.Drawing.Size(239, 48)
        Me.btn_About.TabIndex = 8
        Me.btn_About.Text = "About"
        Me.btn_About.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_About.Textcolor = System.Drawing.Color.White
        Me.btn_About.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(48, 173)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 23)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Kevin A. Mendi"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.ErrorImage = Nothing
        Me.PictureBox2.Location = New System.Drawing.Point(52, 26)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(128, 121)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 8
        Me.PictureBox2.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Gray
        Me.Label5.Location = New System.Drawing.Point(49, 586)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(114, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Thesis Version 1.0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Gray
        Me.Label6.Location = New System.Drawing.Point(77, 603)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(68, 17)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "2017-2018"
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.ErrorImage = Nothing
        Me.PictureBox3.Location = New System.Drawing.Point(21, 586)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(22, 17)
        Me.PictureBox3.TabIndex = 11
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.ErrorImage = Nothing
        Me.PictureBox4.Location = New System.Drawing.Point(174, 586)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(22, 17)
        Me.PictureBox4.TabIndex = 12
        Me.PictureBox4.TabStop = False
        '
        'pnl_menu
        '
        Me.pnl_menu.BackColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.pnl_menu.Controls.Add(Me.PictureBox4)
        Me.pnl_menu.Controls.Add(Me.PictureBox3)
        Me.pnl_menu.Controls.Add(Me.Label6)
        Me.pnl_menu.Controls.Add(Me.Label5)
        Me.pnl_menu.Controls.Add(Me.PictureBox2)
        Me.pnl_menu.Controls.Add(Me.Label3)
        Me.pnl_menu.Controls.Add(Me.btn_About)
        Me.pnl_menu.Controls.Add(Me.btn_Reports)
        Me.pnl_menu.Controls.Add(Me.btn_MPM)
        Me.pnl_menu.Controls.Add(Me.btn_UP)
        Me.pnl_menu.Controls.Add(Me.btn_analyzeBeans)
        Me.pnl_menu.Location = New System.Drawing.Point(0, 26)
        Me.pnl_menu.Name = "pnl_menu"
        Me.pnl_menu.Size = New System.Drawing.Size(242, 622)
        Me.pnl_menu.TabIndex = 0
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 800
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe Print", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.SeaGreen
        Me.Label9.Location = New System.Drawing.Point(386, 5)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(394, 62)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Manage Price Matrix"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(9, 61)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(106, 23)
        Me.Label36.TabIndex = 24
        Me.Label36.Text = "Beans Size"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(172, 61)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(159, 23)
        Me.Label37.TabIndex = 25
        Me.Label37.Text = "Over Fermented"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(386, 64)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(68, 23)
        Me.Label38.TabIndex = 26
        Me.Label38.Text = "Purple"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(534, 61)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(70, 23)
        Me.Label39.TabIndex = 27
        Me.Label39.Text = "Defect"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(631, 64)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(146, 23)
        Me.Label40.TabIndex = 28
        Me.Label40.Text = "Price Multiplier"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(41, 93)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(29, 17)
        Me.Label41.TabIndex = 29
        Me.Label41.Text = "<80"
        '
        'pnl_MPM
        '
        Me.pnl_MPM.Controls.Add(Me.tb_pm26)
        Me.pnl_MPM.Controls.Add(Me.Label147)
        Me.pnl_MPM.Controls.Add(Me.Label146)
        Me.pnl_MPM.Controls.Add(Me.Label145)
        Me.pnl_MPM.Controls.Add(Me.Label4)
        Me.pnl_MPM.Controls.Add(Me.tb_pm25)
        Me.pnl_MPM.Controls.Add(Me.tb_pm24)
        Me.pnl_MPM.Controls.Add(Me.tb_pm23)
        Me.pnl_MPM.Controls.Add(Me.tb_pm22)
        Me.pnl_MPM.Controls.Add(Me.tb_pm21)
        Me.pnl_MPM.Controls.Add(Me.tb_pm20)
        Me.pnl_MPM.Controls.Add(Me.tb_pm19)
        Me.pnl_MPM.Controls.Add(Me.tb_pm18)
        Me.pnl_MPM.Controls.Add(Me.tb_pm17)
        Me.pnl_MPM.Controls.Add(Me.tb_pm16)
        Me.pnl_MPM.Controls.Add(Me.tb_pm15)
        Me.pnl_MPM.Controls.Add(Me.tb_pm14)
        Me.pnl_MPM.Controls.Add(Me.tb_pm13)
        Me.pnl_MPM.Controls.Add(Me.tb_pm12)
        Me.pnl_MPM.Controls.Add(Me.tb_pm11)
        Me.pnl_MPM.Controls.Add(Me.tb_pm10)
        Me.pnl_MPM.Controls.Add(Me.tb_pm9)
        Me.pnl_MPM.Controls.Add(Me.Panel9)
        Me.pnl_MPM.Controls.Add(Me.BunifuFlatButton1)
        Me.pnl_MPM.Controls.Add(Me.tb_pm8)
        Me.pnl_MPM.Controls.Add(Me.tb_pm7)
        Me.pnl_MPM.Controls.Add(Me.tb_pm6)
        Me.pnl_MPM.Controls.Add(Me.tb_pm5)
        Me.pnl_MPM.Controls.Add(Me.tb_pm4)
        Me.pnl_MPM.Controls.Add(Me.tb_pm3)
        Me.pnl_MPM.Controls.Add(Me.tb_pm2)
        Me.pnl_MPM.Controls.Add(Me.tb_pm1)
        Me.pnl_MPM.Controls.Add(Me.Panel8)
        Me.pnl_MPM.Controls.Add(Me.Label140)
        Me.pnl_MPM.Controls.Add(Me.Label139)
        Me.pnl_MPM.Controls.Add(Me.Label138)
        Me.pnl_MPM.Controls.Add(Me.Label137)
        Me.pnl_MPM.Controls.Add(Me.Label129)
        Me.pnl_MPM.Controls.Add(Me.Label130)
        Me.pnl_MPM.Controls.Add(Me.Label131)
        Me.pnl_MPM.Controls.Add(Me.Label132)
        Me.pnl_MPM.Controls.Add(Me.Label133)
        Me.pnl_MPM.Controls.Add(Me.Label134)
        Me.pnl_MPM.Controls.Add(Me.Label135)
        Me.pnl_MPM.Controls.Add(Me.Label136)
        Me.pnl_MPM.Controls.Add(Me.Label121)
        Me.pnl_MPM.Controls.Add(Me.Label122)
        Me.pnl_MPM.Controls.Add(Me.Label123)
        Me.pnl_MPM.Controls.Add(Me.Label124)
        Me.pnl_MPM.Controls.Add(Me.Label125)
        Me.pnl_MPM.Controls.Add(Me.Label126)
        Me.pnl_MPM.Controls.Add(Me.Label127)
        Me.pnl_MPM.Controls.Add(Me.Label128)
        Me.pnl_MPM.Controls.Add(Me.Label113)
        Me.pnl_MPM.Controls.Add(Me.Label114)
        Me.pnl_MPM.Controls.Add(Me.Label115)
        Me.pnl_MPM.Controls.Add(Me.Label116)
        Me.pnl_MPM.Controls.Add(Me.Label117)
        Me.pnl_MPM.Controls.Add(Me.Label118)
        Me.pnl_MPM.Controls.Add(Me.Label119)
        Me.pnl_MPM.Controls.Add(Me.Label120)
        Me.pnl_MPM.Controls.Add(Me.Label105)
        Me.pnl_MPM.Controls.Add(Me.Label106)
        Me.pnl_MPM.Controls.Add(Me.Label107)
        Me.pnl_MPM.Controls.Add(Me.Label108)
        Me.pnl_MPM.Controls.Add(Me.Label109)
        Me.pnl_MPM.Controls.Add(Me.Label110)
        Me.pnl_MPM.Controls.Add(Me.Label111)
        Me.pnl_MPM.Controls.Add(Me.Label112)
        Me.pnl_MPM.Controls.Add(Me.Panel6)
        Me.pnl_MPM.Controls.Add(Me.Label97)
        Me.pnl_MPM.Controls.Add(Me.Label98)
        Me.pnl_MPM.Controls.Add(Me.Label99)
        Me.pnl_MPM.Controls.Add(Me.Label100)
        Me.pnl_MPM.Controls.Add(Me.Label101)
        Me.pnl_MPM.Controls.Add(Me.Label102)
        Me.pnl_MPM.Controls.Add(Me.Label103)
        Me.pnl_MPM.Controls.Add(Me.Label104)
        Me.pnl_MPM.Controls.Add(Me.Label89)
        Me.pnl_MPM.Controls.Add(Me.Label90)
        Me.pnl_MPM.Controls.Add(Me.Label91)
        Me.pnl_MPM.Controls.Add(Me.Label92)
        Me.pnl_MPM.Controls.Add(Me.Label93)
        Me.pnl_MPM.Controls.Add(Me.Label94)
        Me.pnl_MPM.Controls.Add(Me.Label95)
        Me.pnl_MPM.Controls.Add(Me.Label96)
        Me.pnl_MPM.Controls.Add(Me.Label81)
        Me.pnl_MPM.Controls.Add(Me.Label82)
        Me.pnl_MPM.Controls.Add(Me.Label83)
        Me.pnl_MPM.Controls.Add(Me.Label84)
        Me.pnl_MPM.Controls.Add(Me.Label85)
        Me.pnl_MPM.Controls.Add(Me.Label86)
        Me.pnl_MPM.Controls.Add(Me.Label87)
        Me.pnl_MPM.Controls.Add(Me.Label88)
        Me.pnl_MPM.Controls.Add(Me.Label73)
        Me.pnl_MPM.Controls.Add(Me.Label74)
        Me.pnl_MPM.Controls.Add(Me.Label75)
        Me.pnl_MPM.Controls.Add(Me.Label76)
        Me.pnl_MPM.Controls.Add(Me.Label77)
        Me.pnl_MPM.Controls.Add(Me.Label78)
        Me.pnl_MPM.Controls.Add(Me.Label79)
        Me.pnl_MPM.Controls.Add(Me.Label80)
        Me.pnl_MPM.Controls.Add(Me.Panel2)
        Me.pnl_MPM.Controls.Add(Me.Label65)
        Me.pnl_MPM.Controls.Add(Me.Label66)
        Me.pnl_MPM.Controls.Add(Me.Label67)
        Me.pnl_MPM.Controls.Add(Me.Label68)
        Me.pnl_MPM.Controls.Add(Me.Label69)
        Me.pnl_MPM.Controls.Add(Me.Label70)
        Me.pnl_MPM.Controls.Add(Me.Label71)
        Me.pnl_MPM.Controls.Add(Me.Label72)
        Me.pnl_MPM.Controls.Add(Me.Label57)
        Me.pnl_MPM.Controls.Add(Me.Label58)
        Me.pnl_MPM.Controls.Add(Me.Label59)
        Me.pnl_MPM.Controls.Add(Me.Label60)
        Me.pnl_MPM.Controls.Add(Me.Label61)
        Me.pnl_MPM.Controls.Add(Me.Label62)
        Me.pnl_MPM.Controls.Add(Me.Label63)
        Me.pnl_MPM.Controls.Add(Me.Label64)
        Me.pnl_MPM.Controls.Add(Me.Label49)
        Me.pnl_MPM.Controls.Add(Me.Label50)
        Me.pnl_MPM.Controls.Add(Me.Label51)
        Me.pnl_MPM.Controls.Add(Me.Label52)
        Me.pnl_MPM.Controls.Add(Me.Label53)
        Me.pnl_MPM.Controls.Add(Me.Label54)
        Me.pnl_MPM.Controls.Add(Me.Label55)
        Me.pnl_MPM.Controls.Add(Me.Label56)
        Me.pnl_MPM.Controls.Add(Me.Label48)
        Me.pnl_MPM.Controls.Add(Me.Label47)
        Me.pnl_MPM.Controls.Add(Me.Label46)
        Me.pnl_MPM.Controls.Add(Me.Label45)
        Me.pnl_MPM.Controls.Add(Me.Label44)
        Me.pnl_MPM.Controls.Add(Me.Label43)
        Me.pnl_MPM.Controls.Add(Me.Label42)
        Me.pnl_MPM.Controls.Add(Me.Label41)
        Me.pnl_MPM.Controls.Add(Me.Label40)
        Me.pnl_MPM.Controls.Add(Me.Label39)
        Me.pnl_MPM.Controls.Add(Me.Label38)
        Me.pnl_MPM.Controls.Add(Me.Label37)
        Me.pnl_MPM.Controls.Add(Me.Label36)
        Me.pnl_MPM.Controls.Add(Me.Label9)
        Me.pnl_MPM.Location = New System.Drawing.Point(245, 30)
        Me.pnl_MPM.Name = "pnl_MPM"
        Me.pnl_MPM.Size = New System.Drawing.Size(783, 616)
        Me.pnl_MPM.TabIndex = 6
        '
        'tb_pm26
        '
        Me.tb_pm26.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm26.Location = New System.Drawing.Point(670, 545)
        Me.tb_pm26.Name = "tb_pm26"
        Me.tb_pm26.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm26.TabIndex = 178
        Me.tb_pm26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label147
        '
        Me.Label147.AutoSize = True
        Me.Label147.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label147.Location = New System.Drawing.Point(542, 542)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(48, 17)
        Me.Label147.TabIndex = 177
        Me.Label147.Text = "0 to 12"
        '
        'Label146
        '
        Me.Label146.AutoSize = True
        Me.Label146.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label146.Location = New System.Drawing.Point(394, 544)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(48, 17)
        Me.Label146.TabIndex = 176
        Me.Label146.Text = "0 to 32"
        '
        'Label145
        '
        Me.Label145.AutoSize = True
        Me.Label145.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label145.Location = New System.Drawing.Point(224, 544)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(41, 17)
        Me.Label145.TabIndex = 175
        Me.Label145.Text = "0 to 5"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(27, 544)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 17)
        Me.Label4.TabIndex = 174
        Me.Label4.Text = "111 to 120"
        '
        'tb_pm25
        '
        Me.tb_pm25.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm25.Location = New System.Drawing.Point(670, 527)
        Me.tb_pm25.Name = "tb_pm25"
        Me.tb_pm25.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm25.TabIndex = 173
        Me.tb_pm25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm24
        '
        Me.tb_pm24.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm24.Location = New System.Drawing.Point(670, 505)
        Me.tb_pm24.Name = "tb_pm24"
        Me.tb_pm24.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm24.TabIndex = 172
        Me.tb_pm24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm23
        '
        Me.tb_pm23.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm23.Location = New System.Drawing.Point(670, 488)
        Me.tb_pm23.Name = "tb_pm23"
        Me.tb_pm23.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm23.TabIndex = 171
        Me.tb_pm23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm22
        '
        Me.tb_pm22.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm22.Location = New System.Drawing.Point(670, 471)
        Me.tb_pm22.Name = "tb_pm22"
        Me.tb_pm22.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm22.TabIndex = 170
        Me.tb_pm22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm21
        '
        Me.tb_pm21.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm21.Location = New System.Drawing.Point(670, 454)
        Me.tb_pm21.Name = "tb_pm21"
        Me.tb_pm21.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm21.TabIndex = 169
        Me.tb_pm21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm20
        '
        Me.tb_pm20.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm20.Location = New System.Drawing.Point(670, 437)
        Me.tb_pm20.Name = "tb_pm20"
        Me.tb_pm20.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm20.TabIndex = 168
        Me.tb_pm20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm19
        '
        Me.tb_pm19.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm19.Location = New System.Drawing.Point(670, 420)
        Me.tb_pm19.Name = "tb_pm19"
        Me.tb_pm19.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm19.TabIndex = 167
        Me.tb_pm19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm18
        '
        Me.tb_pm18.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm18.Location = New System.Drawing.Point(670, 403)
        Me.tb_pm18.Name = "tb_pm18"
        Me.tb_pm18.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm18.TabIndex = 166
        Me.tb_pm18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm17
        '
        Me.tb_pm17.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm17.Location = New System.Drawing.Point(670, 386)
        Me.tb_pm17.Name = "tb_pm17"
        Me.tb_pm17.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm17.TabIndex = 165
        Me.tb_pm17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm16
        '
        Me.tb_pm16.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm16.Location = New System.Drawing.Point(670, 356)
        Me.tb_pm16.Name = "tb_pm16"
        Me.tb_pm16.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm16.TabIndex = 164
        Me.tb_pm16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm15
        '
        Me.tb_pm15.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm15.Location = New System.Drawing.Point(670, 339)
        Me.tb_pm15.Name = "tb_pm15"
        Me.tb_pm15.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm15.TabIndex = 163
        Me.tb_pm15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm14
        '
        Me.tb_pm14.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm14.Location = New System.Drawing.Point(670, 322)
        Me.tb_pm14.Name = "tb_pm14"
        Me.tb_pm14.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm14.TabIndex = 162
        Me.tb_pm14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm13
        '
        Me.tb_pm13.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm13.Location = New System.Drawing.Point(670, 305)
        Me.tb_pm13.Name = "tb_pm13"
        Me.tb_pm13.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm13.TabIndex = 161
        Me.tb_pm13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm12
        '
        Me.tb_pm12.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm12.Location = New System.Drawing.Point(670, 288)
        Me.tb_pm12.Name = "tb_pm12"
        Me.tb_pm12.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm12.TabIndex = 160
        Me.tb_pm12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm11
        '
        Me.tb_pm11.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm11.Location = New System.Drawing.Point(670, 271)
        Me.tb_pm11.Name = "tb_pm11"
        Me.tb_pm11.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm11.TabIndex = 159
        Me.tb_pm11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm10
        '
        Me.tb_pm10.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm10.Location = New System.Drawing.Point(670, 254)
        Me.tb_pm10.Name = "tb_pm10"
        Me.tb_pm10.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm10.TabIndex = 158
        Me.tb_pm10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm9
        '
        Me.tb_pm9.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm9.Location = New System.Drawing.Point(670, 237)
        Me.tb_pm9.Name = "tb_pm9"
        Me.tb_pm9.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm9.TabIndex = 157
        Me.tb_pm9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.SeaGreen
        Me.Panel9.Location = New System.Drawing.Point(0, 564)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(626, 5)
        Me.Panel9.TabIndex = 64
        '
        'BunifuFlatButton1
        '
        Me.BunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton1.BorderRadius = 0
        Me.BunifuFlatButton1.ButtonText = "Update"
        Me.BunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton1.Iconimage = CType(resources.GetObject("BunifuFlatButton1.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton1.Iconimage_right = Nothing
        Me.BunifuFlatButton1.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton1.Iconimage_Selected = Nothing
        Me.BunifuFlatButton1.IconMarginLeft = 0
        Me.BunifuFlatButton1.IconMarginRight = 0
        Me.BunifuFlatButton1.IconRightVisible = True
        Me.BunifuFlatButton1.IconRightZoom = 0.0R
        Me.BunifuFlatButton1.IconVisible = True
        Me.BunifuFlatButton1.IconZoom = 90.0R
        Me.BunifuFlatButton1.IsTab = False
        Me.BunifuFlatButton1.Location = New System.Drawing.Point(642, 574)
        Me.BunifuFlatButton1.Name = "BunifuFlatButton1"
        Me.BunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.BunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton1.selected = False
        Me.BunifuFlatButton1.Size = New System.Drawing.Size(120, 36)
        Me.BunifuFlatButton1.TabIndex = 156
        Me.BunifuFlatButton1.Text = "Update"
        Me.BunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton1.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'tb_pm8
        '
        Me.tb_pm8.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm8.Location = New System.Drawing.Point(670, 209)
        Me.tb_pm8.Name = "tb_pm8"
        Me.tb_pm8.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm8.TabIndex = 138
        Me.tb_pm8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm7
        '
        Me.tb_pm7.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm7.Location = New System.Drawing.Point(670, 192)
        Me.tb_pm7.Name = "tb_pm7"
        Me.tb_pm7.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm7.TabIndex = 137
        Me.tb_pm7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm6
        '
        Me.tb_pm6.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm6.Location = New System.Drawing.Point(670, 175)
        Me.tb_pm6.Name = "tb_pm6"
        Me.tb_pm6.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm6.TabIndex = 136
        Me.tb_pm6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm5
        '
        Me.tb_pm5.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm5.Location = New System.Drawing.Point(670, 158)
        Me.tb_pm5.Name = "tb_pm5"
        Me.tb_pm5.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm5.TabIndex = 135
        Me.tb_pm5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm4
        '
        Me.tb_pm4.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm4.Location = New System.Drawing.Point(670, 141)
        Me.tb_pm4.Name = "tb_pm4"
        Me.tb_pm4.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm4.TabIndex = 134
        Me.tb_pm4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm3
        '
        Me.tb_pm3.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm3.Location = New System.Drawing.Point(670, 124)
        Me.tb_pm3.Name = "tb_pm3"
        Me.tb_pm3.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm3.TabIndex = 133
        Me.tb_pm3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm2
        '
        Me.tb_pm2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm2.Location = New System.Drawing.Point(670, 107)
        Me.tb_pm2.Name = "tb_pm2"
        Me.tb_pm2.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm2.TabIndex = 132
        Me.tb_pm2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tb_pm1
        '
        Me.tb_pm1.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_pm1.Location = New System.Drawing.Point(670, 90)
        Me.tb_pm1.Name = "tb_pm1"
        Me.tb_pm1.Size = New System.Drawing.Size(63, 22)
        Me.tb_pm1.TabIndex = 131
        Me.tb_pm1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.SeaGreen
        Me.Panel8.Location = New System.Drawing.Point(616, 75)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(8, 493)
        Me.Panel8.TabIndex = 130
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label140.Location = New System.Drawing.Point(542, 525)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(48, 17)
        Me.Label140.TabIndex = 129
        Me.Label140.Text = "0 to 12"
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label139.Location = New System.Drawing.Point(394, 527)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(48, 17)
        Me.Label139.TabIndex = 128
        Me.Label139.Text = "0 to 32"
        '
        'Label138
        '
        Me.Label138.AutoSize = True
        Me.Label138.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label138.Location = New System.Drawing.Point(224, 527)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(41, 17)
        Me.Label138.TabIndex = 127
        Me.Label138.Text = "0 to 5"
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label137.Location = New System.Drawing.Point(27, 527)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(69, 17)
        Me.Label137.TabIndex = 126
        Me.Label137.Text = "101 to 110"
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label129.Location = New System.Drawing.Point(542, 508)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(48, 17)
        Me.Label129.TabIndex = 125
        Me.Label129.Text = "6 to 12"
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label130.Location = New System.Drawing.Point(542, 491)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(41, 17)
        Me.Label130.TabIndex = 124
        Me.Label130.Text = "0 to 5"
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label131.Location = New System.Drawing.Point(542, 474)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(48, 17)
        Me.Label131.TabIndex = 123
        Me.Label131.Text = "6 to 12"
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label132.Location = New System.Drawing.Point(542, 457)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(41, 17)
        Me.Label132.TabIndex = 122
        Me.Label132.Text = "0 to 5"
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label133.Location = New System.Drawing.Point(542, 440)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(48, 17)
        Me.Label133.TabIndex = 121
        Me.Label133.Text = "6 to 12"
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label134.Location = New System.Drawing.Point(542, 423)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(41, 17)
        Me.Label134.TabIndex = 120
        Me.Label134.Text = "0 to 5"
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label135.Location = New System.Drawing.Point(542, 406)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(48, 17)
        Me.Label135.TabIndex = 119
        Me.Label135.Text = "6 to 12"
        '
        'Label136
        '
        Me.Label136.AutoSize = True
        Me.Label136.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label136.Location = New System.Drawing.Point(542, 389)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(41, 17)
        Me.Label136.TabIndex = 118
        Me.Label136.Text = "0 to 5"
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label121.Location = New System.Drawing.Point(392, 510)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(55, 17)
        Me.Label121.TabIndex = 117
        Me.Label121.Text = "16 to 32"
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label122.Location = New System.Drawing.Point(392, 493)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(55, 17)
        Me.Label122.TabIndex = 116
        Me.Label122.Text = "16 to 32"
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label123.Location = New System.Drawing.Point(392, 476)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(48, 17)
        Me.Label123.TabIndex = 115
        Me.Label123.Text = "0 to 15"
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label124.Location = New System.Drawing.Point(392, 459)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(48, 17)
        Me.Label124.TabIndex = 114
        Me.Label124.Text = "0 to 15"
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label125.Location = New System.Drawing.Point(392, 442)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(55, 17)
        Me.Label125.TabIndex = 113
        Me.Label125.Text = "16 to 32"
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label126.Location = New System.Drawing.Point(392, 425)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(55, 17)
        Me.Label126.TabIndex = 112
        Me.Label126.Text = "16 to 32"
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label127.Location = New System.Drawing.Point(392, 408)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(48, 17)
        Me.Label127.TabIndex = 111
        Me.Label127.Text = "0 to 15"
        '
        'Label128
        '
        Me.Label128.AutoSize = True
        Me.Label128.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label128.Location = New System.Drawing.Point(392, 391)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(48, 17)
        Me.Label128.TabIndex = 110
        Me.Label128.Text = "0 to 15"
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label113.Location = New System.Drawing.Point(224, 510)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(41, 17)
        Me.Label113.TabIndex = 109
        Me.Label113.Text = "3 to 5"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label114.Location = New System.Drawing.Point(224, 493)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(41, 17)
        Me.Label114.TabIndex = 108
        Me.Label114.Text = "3 to 5"
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label115.Location = New System.Drawing.Point(224, 476)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(41, 17)
        Me.Label115.TabIndex = 107
        Me.Label115.Text = "3 to 5"
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label116.Location = New System.Drawing.Point(224, 459)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(41, 17)
        Me.Label116.TabIndex = 106
        Me.Label116.Text = "3 to 5"
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label117.Location = New System.Drawing.Point(224, 442)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(41, 17)
        Me.Label117.TabIndex = 105
        Me.Label117.Text = "0 to 2"
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label118.Location = New System.Drawing.Point(224, 425)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(41, 17)
        Me.Label118.TabIndex = 104
        Me.Label118.Text = "0 to 2"
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label119.Location = New System.Drawing.Point(224, 408)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(41, 17)
        Me.Label119.TabIndex = 103
        Me.Label119.Text = "0 to 2"
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label120.Location = New System.Drawing.Point(224, 391)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(41, 17)
        Me.Label120.TabIndex = 102
        Me.Label120.Text = "0 to 2"
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.Location = New System.Drawing.Point(27, 510)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(62, 17)
        Me.Label105.TabIndex = 101
        Me.Label105.Text = "91 to 100"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(27, 493)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(62, 17)
        Me.Label106.TabIndex = 100
        Me.Label106.Text = "91 to 100"
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.Location = New System.Drawing.Point(27, 476)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(62, 17)
        Me.Label107.TabIndex = 99
        Me.Label107.Text = "91 to 100"
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.Location = New System.Drawing.Point(27, 459)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(62, 17)
        Me.Label108.TabIndex = 98
        Me.Label108.Text = "91 to 100"
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label109.Location = New System.Drawing.Point(27, 442)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(62, 17)
        Me.Label109.TabIndex = 97
        Me.Label109.Text = "91 to 100"
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label110.Location = New System.Drawing.Point(27, 425)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(62, 17)
        Me.Label110.TabIndex = 96
        Me.Label110.Text = "91 to 100"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label111.Location = New System.Drawing.Point(27, 408)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(62, 17)
        Me.Label111.TabIndex = 95
        Me.Label111.Text = "91 to 100"
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label112.Location = New System.Drawing.Point(27, 391)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(62, 17)
        Me.Label112.TabIndex = 94
        Me.Label112.Text = "91 to 100"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.SeaGreen
        Me.Panel6.Location = New System.Drawing.Point(3, 379)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(615, 5)
        Me.Panel6.TabIndex = 62
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label97.Location = New System.Drawing.Point(542, 359)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(48, 17)
        Me.Label97.TabIndex = 93
        Me.Label97.Text = "6 to 12"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.Location = New System.Drawing.Point(542, 342)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(41, 17)
        Me.Label98.TabIndex = 92
        Me.Label98.Text = "0 to 5"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label99.Location = New System.Drawing.Point(542, 325)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(48, 17)
        Me.Label99.TabIndex = 91
        Me.Label99.Text = "6 to 12"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label100.Location = New System.Drawing.Point(542, 308)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(41, 17)
        Me.Label100.TabIndex = 90
        Me.Label100.Text = "0 to 5"
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label101.Location = New System.Drawing.Point(542, 291)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(48, 17)
        Me.Label101.TabIndex = 89
        Me.Label101.Text = "6 to 12"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label102.Location = New System.Drawing.Point(542, 274)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(41, 17)
        Me.Label102.TabIndex = 88
        Me.Label102.Text = "0 to 5"
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(542, 257)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(48, 17)
        Me.Label103.TabIndex = 87
        Me.Label103.Text = "6 to 12"
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(542, 240)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(41, 17)
        Me.Label104.TabIndex = 86
        Me.Label104.Text = "0 to 5"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(392, 359)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(55, 17)
        Me.Label89.TabIndex = 85
        Me.Label89.Text = "16 to 32"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(392, 342)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(55, 17)
        Me.Label90.TabIndex = 84
        Me.Label90.Text = "16 to 32"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(392, 325)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(48, 17)
        Me.Label91.TabIndex = 83
        Me.Label91.Text = "0 to 15"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(392, 308)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(48, 17)
        Me.Label92.TabIndex = 82
        Me.Label92.Text = "0 to 15"
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.Location = New System.Drawing.Point(392, 291)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(55, 17)
        Me.Label93.TabIndex = 81
        Me.Label93.Text = "16 to 32"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.Location = New System.Drawing.Point(392, 274)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(55, 17)
        Me.Label94.TabIndex = 80
        Me.Label94.Text = "16 to 32"
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(392, 257)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(48, 17)
        Me.Label95.TabIndex = 79
        Me.Label95.Text = "0 to 15"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label96.Location = New System.Drawing.Point(392, 240)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(48, 17)
        Me.Label96.TabIndex = 78
        Me.Label96.Text = "0 to 15"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.Location = New System.Drawing.Point(224, 359)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(41, 17)
        Me.Label81.TabIndex = 77
        Me.Label81.Text = "3 to 5"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(224, 342)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(41, 17)
        Me.Label82.TabIndex = 76
        Me.Label82.Text = "3 to 5"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(224, 325)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(41, 17)
        Me.Label83.TabIndex = 75
        Me.Label83.Text = "3 to 5"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(224, 308)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(41, 17)
        Me.Label84.TabIndex = 74
        Me.Label84.Text = "3 to 5"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(224, 291)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(41, 17)
        Me.Label85.TabIndex = 73
        Me.Label85.Text = "0 to 2"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(224, 274)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(41, 17)
        Me.Label86.TabIndex = 72
        Me.Label86.Text = "0 to 2"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.Location = New System.Drawing.Point(224, 257)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(41, 17)
        Me.Label87.TabIndex = 71
        Me.Label87.Text = "0 to 2"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(224, 240)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(41, 17)
        Me.Label88.TabIndex = 70
        Me.Label88.Text = "0 to 2"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(27, 359)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(55, 17)
        Me.Label73.TabIndex = 69
        Me.Label73.Text = "81 to 90"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.Location = New System.Drawing.Point(27, 342)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(55, 17)
        Me.Label74.TabIndex = 68
        Me.Label74.Text = "81 to 90"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(27, 325)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(55, 17)
        Me.Label75.TabIndex = 67
        Me.Label75.Text = "81 to 90"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(27, 308)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(55, 17)
        Me.Label76.TabIndex = 66
        Me.Label76.Text = "81 to 90"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(27, 291)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(55, 17)
        Me.Label77.TabIndex = 65
        Me.Label77.Text = "81 to 90"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(27, 274)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(55, 17)
        Me.Label78.TabIndex = 64
        Me.Label78.Text = "81 to 90"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(27, 257)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(55, 17)
        Me.Label79.TabIndex = 63
        Me.Label79.Text = "81 to 90"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(27, 240)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(55, 17)
        Me.Label80.TabIndex = 62
        Me.Label80.Text = "81 to 90"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SeaGreen
        Me.Panel2.Location = New System.Drawing.Point(3, 232)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(618, 5)
        Me.Panel2.TabIndex = 61
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(542, 212)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(48, 17)
        Me.Label65.TabIndex = 60
        Me.Label65.Text = "6 to 12"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(542, 195)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(41, 17)
        Me.Label66.TabIndex = 59
        Me.Label66.Text = "0 to 5"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(542, 178)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(48, 17)
        Me.Label67.TabIndex = 58
        Me.Label67.Text = "6 to 12"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(542, 161)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(41, 17)
        Me.Label68.TabIndex = 57
        Me.Label68.Text = "0 to 5"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(542, 144)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(48, 17)
        Me.Label69.TabIndex = 56
        Me.Label69.Text = "6 to 12"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(542, 127)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(41, 17)
        Me.Label70.TabIndex = 55
        Me.Label70.Text = "0 to 5"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(542, 110)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(48, 17)
        Me.Label71.TabIndex = 54
        Me.Label71.Text = "6 to 12"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.Location = New System.Drawing.Point(542, 93)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(41, 17)
        Me.Label72.TabIndex = 53
        Me.Label72.Text = "0 to 5"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(394, 212)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(55, 17)
        Me.Label57.TabIndex = 52
        Me.Label57.Text = "16 to 32"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(394, 195)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(55, 17)
        Me.Label58.TabIndex = 51
        Me.Label58.Text = "16 to 32"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(394, 178)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(48, 17)
        Me.Label59.TabIndex = 50
        Me.Label59.Text = "0 to 15"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(394, 161)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(48, 17)
        Me.Label60.TabIndex = 49
        Me.Label60.Text = "0 to 15"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(394, 144)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(55, 17)
        Me.Label61.TabIndex = 48
        Me.Label61.Text = "16 to 32"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(394, 127)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(55, 17)
        Me.Label62.TabIndex = 47
        Me.Label62.Text = "16 to 32"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(394, 110)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(48, 17)
        Me.Label63.TabIndex = 46
        Me.Label63.Text = "0 to 15"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(394, 93)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(48, 17)
        Me.Label64.TabIndex = 45
        Me.Label64.Text = "0 to 15"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(224, 212)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(41, 17)
        Me.Label49.TabIndex = 44
        Me.Label49.Text = "3 to 5"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(224, 195)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(41, 17)
        Me.Label50.TabIndex = 43
        Me.Label50.Text = "3 to 5"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(224, 178)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(41, 17)
        Me.Label51.TabIndex = 42
        Me.Label51.Text = "3 to 5"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(224, 161)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(41, 17)
        Me.Label52.TabIndex = 41
        Me.Label52.Text = "3 to 5"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(224, 144)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(41, 17)
        Me.Label53.TabIndex = 40
        Me.Label53.Text = "0 to 2"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(224, 127)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(41, 17)
        Me.Label54.TabIndex = 39
        Me.Label54.Text = "0 to 2"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(224, 110)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(41, 17)
        Me.Label55.TabIndex = 38
        Me.Label55.Text = "0 to 2"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(224, 93)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(41, 17)
        Me.Label56.TabIndex = 37
        Me.Label56.Text = "0 to 2"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(41, 212)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(29, 17)
        Me.Label48.TabIndex = 36
        Me.Label48.Text = "<80"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(41, 195)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(29, 17)
        Me.Label47.TabIndex = 35
        Me.Label47.Text = "<80"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(41, 178)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(29, 17)
        Me.Label46.TabIndex = 34
        Me.Label46.Text = "<80"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(41, 161)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(29, 17)
        Me.Label45.TabIndex = 33
        Me.Label45.Text = "<80"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(41, 144)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(29, 17)
        Me.Label44.TabIndex = 32
        Me.Label44.Text = "<80"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(41, 127)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(29, 17)
        Me.Label43.TabIndex = 31
        Me.Label43.Text = "<80"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(41, 110)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(29, 17)
        Me.Label42.TabIndex = 30
        Me.Label42.Text = "<80"
        '
        'Timer2
        '
        Me.Timer2.Interval = 500
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'lbgauge_Well
        '
        Me.lbgauge_Well.AutoSize = True
        Me.lbgauge_Well.Font = New System.Drawing.Font("Century Gothic", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbgauge_Well.ForeColor = System.Drawing.Color.SeaGreen
        Me.lbgauge_Well.Location = New System.Drawing.Point(66, 231)
        Me.lbgauge_Well.Name = "lbgauge_Well"
        Me.lbgauge_Well.Size = New System.Drawing.Size(138, 78)
        Me.lbgauge_Well.TabIndex = 54
        Me.lbgauge_Well.Text = "000"
        '
        'lbgauge_Over
        '
        Me.lbgauge_Over.AutoSize = True
        Me.lbgauge_Over.Font = New System.Drawing.Font("Century Gothic", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbgauge_Over.ForeColor = System.Drawing.Color.SeaGreen
        Me.lbgauge_Over.Location = New System.Drawing.Point(571, 231)
        Me.lbgauge_Over.Name = "lbgauge_Over"
        Me.lbgauge_Over.Size = New System.Drawing.Size(138, 78)
        Me.lbgauge_Over.TabIndex = 55
        Me.lbgauge_Over.Text = "000"
        '
        'lbgauge_Under
        '
        Me.lbgauge_Under.AutoSize = True
        Me.lbgauge_Under.Font = New System.Drawing.Font("Century Gothic", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbgauge_Under.ForeColor = System.Drawing.Color.SeaGreen
        Me.lbgauge_Under.Location = New System.Drawing.Point(56, 319)
        Me.lbgauge_Under.Name = "lbgauge_Under"
        Me.lbgauge_Under.Size = New System.Drawing.Size(138, 78)
        Me.lbgauge_Under.TabIndex = 56
        Me.lbgauge_Under.Text = "000"
        '
        'lbgauge_Reject
        '
        Me.lbgauge_Reject.AutoSize = True
        Me.lbgauge_Reject.Font = New System.Drawing.Font("Century Gothic", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbgauge_Reject.ForeColor = System.Drawing.Color.SeaGreen
        Me.lbgauge_Reject.Location = New System.Drawing.Point(571, 316)
        Me.lbgauge_Reject.Name = "lbgauge_Reject"
        Me.lbgauge_Reject.Size = New System.Drawing.Size(138, 78)
        Me.lbgauge_Reject.TabIndex = 57
        Me.lbgauge_Reject.Text = "000"
        '
        'frm_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1034, 648)
        Me.Controls.Add(Me.pnl_AB)
        Me.Controls.Add(Me.pnl_MPM)
        Me.Controls.Add(Me.pnl_Reports)
        Me.Controls.Add(Me.pnl_UP)
        Me.Controls.Add(Me.pnl_About)
        Me.Controls.Add(Me.pnl_top)
        Me.Controls.Add(Me.pnl_menu)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frm_Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frm_Main"
        Me.pnl_AB.ResumeLayout(False)
        Me.pnl_step3.ResumeLayout(False)
        Me.pnl_step3.PerformLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.pnl_step1.ResumeLayout(False)
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_step2.ResumeLayout(False)
        Me.pnl_step2.PerformLayout()
        CType(Me.pb2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.pnl_UP.ResumeLayout(False)
        Me.pnl_UP.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.photo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_Reports.ResumeLayout(False)
        Me.pnl_Reports.PerformLayout()
        Me.pnl_About.ResumeLayout(False)
        Me.pnl_About.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_top.ResumeLayout(False)
        Me.pnl_top.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_menu.ResumeLayout(False)
        Me.pnl_menu.PerformLayout()
        Me.pnl_MPM.ResumeLayout(False)
        Me.pnl_MPM.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents pnl_AB As System.Windows.Forms.Panel
    Friend WithEvents pnl_UP As System.Windows.Forms.Panel
    Friend WithEvents pnl_Reports As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents pnl_About As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents pnl_top As System.Windows.Forms.Panel
    Friend WithEvents btn_analyzeBeans As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_UP As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_MPM As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_Reports As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_About As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents pnl_menu As System.Windows.Forms.Panel
    Friend WithEvents btn_step3 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents btn_step2 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents btn_step1 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents pnl_step3 As System.Windows.Forms.Panel
    Friend WithEvents pnl_step1 As System.Windows.Forms.Panel
    Friend WithEvents pnl_step2 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents btn_new As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents btn_cancel As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents btn_save As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents btn_start As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents btn_capture As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents pb2 As System.Windows.Forms.PictureBox
    Friend WithEvents pb1 As System.Windows.Forms.PictureBox
    Friend WithEvents pb0 As System.Windows.Forms.PictureBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents BunifuProgressBar1 As Bunifu.Framework.UI.BunifuProgressBar
    Friend WithEvents BunifuThinButton21 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents lbl_pm As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents gauge_Reject As Bunifu.Framework.UI.BunifuGauge
    Friend WithEvents gauge_Over As Bunifu.Framework.UI.BunifuGauge
    Friend WithEvents gauge_Well As Bunifu.Framework.UI.BunifuGauge
    Friend WithEvents gauge_Under As Bunifu.Framework.UI.BunifuGauge
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents tb_Address As Thesis1_V1.Watermark
    Friend WithEvents tb_CN As Thesis1_V1.Watermark
    Friend WithEvents tb_Age As Thesis1_V1.Watermark
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents tb_Name As Thesis1_V1.Watermark
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents BunifuThinButton22 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents photo As System.Windows.Forms.PictureBox
    Friend WithEvents cb_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents tb_Email As Thesis1_V1.Watermark
    Friend WithEvents tb_Pass As Thesis1_V1.Watermark
    Friend WithEvents tb_Username As Thesis1_V1.Watermark
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents tb_CPass As Thesis1_V1.Watermark
    Friend WithEvents BunifuThinButton26 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton25 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton24 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton23 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents pnl_MPM As System.Windows.Forms.Panel
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label140 As System.Windows.Forms.Label
    Friend WithEvents Label139 As System.Windows.Forms.Label
    Friend WithEvents Label138 As System.Windows.Forms.Label
    Friend WithEvents Label137 As System.Windows.Forms.Label
    Friend WithEvents Label129 As System.Windows.Forms.Label
    Friend WithEvents Label130 As System.Windows.Forms.Label
    Friend WithEvents Label131 As System.Windows.Forms.Label
    Friend WithEvents Label132 As System.Windows.Forms.Label
    Friend WithEvents Label133 As System.Windows.Forms.Label
    Friend WithEvents Label134 As System.Windows.Forms.Label
    Friend WithEvents Label135 As System.Windows.Forms.Label
    Friend WithEvents Label136 As System.Windows.Forms.Label
    Friend WithEvents Label121 As System.Windows.Forms.Label
    Friend WithEvents Label122 As System.Windows.Forms.Label
    Friend WithEvents Label123 As System.Windows.Forms.Label
    Friend WithEvents Label124 As System.Windows.Forms.Label
    Friend WithEvents Label125 As System.Windows.Forms.Label
    Friend WithEvents Label126 As System.Windows.Forms.Label
    Friend WithEvents Label127 As System.Windows.Forms.Label
    Friend WithEvents Label128 As System.Windows.Forms.Label
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents Label119 As System.Windows.Forms.Label
    Friend WithEvents Label120 As System.Windows.Forms.Label
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents tb_pm1 As System.Windows.Forms.TextBox
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents tb_pm8 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm7 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm6 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm5 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm4 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm3 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm2 As System.Windows.Forms.TextBox
    Friend WithEvents BunifuFlatButton1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label141 As System.Windows.Forms.Label
    Friend WithEvents Label144 As System.Windows.Forms.Label
    Friend WithEvents Label143 As System.Windows.Forms.Label
    Friend WithEvents Label142 As System.Windows.Forms.Label
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents BunifuFlatButton2 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents tb_pm25 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm24 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm23 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm22 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm21 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm20 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm19 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm18 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm17 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm16 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm15 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm14 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm13 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm12 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm11 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm10 As System.Windows.Forms.TextBox
    Friend WithEvents tb_pm9 As System.Windows.Forms.TextBox
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lbl_Ototal As System.Windows.Forms.Label
    Friend WithEvents tb_pm26 As System.Windows.Forms.TextBox
    Friend WithEvents Label147 As System.Windows.Forms.Label
    Friend WithEvents Label146 As System.Windows.Forms.Label
    Friend WithEvents Label145 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label148 As System.Windows.Forms.Label
    Friend WithEvents lbl_ID As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents lbgauge_Over As System.Windows.Forms.Label
    Friend WithEvents lbgauge_Well As System.Windows.Forms.Label
    Friend WithEvents lbgauge_Reject As System.Windows.Forms.Label
    Friend WithEvents lbgauge_Under As System.Windows.Forms.Label
End Class
